// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "MoveNone2Walkable.generated.h"

/**
 * 
 */
UCLASS()
class SOULLIKEPROJECT_API UMoveNone2Walkable : public UAnimNotify
{
	GENERATED_BODY()
	
};
