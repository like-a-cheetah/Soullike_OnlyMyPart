// Fill out your copyright notice in the Description page of Project Settings.


#include "Interface/CharacterWidgetInterface.h"

// Add default functionality here for any ICharacterWidgetInterface functions that are not pure virtual.
